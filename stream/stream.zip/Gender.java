package com.company;

public enum Gender {
    M,F
}