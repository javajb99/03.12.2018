package com.company;


	public enum City {
	       A,B,C,D,E,F,G,H
	}