package com.company;

public class IntegerCommon {

	public static boolean get2Int(Integer i1)
	{
		///....
		///.....
		// .................................
		return i1 > 0;
	}
	
}
